package com.assessment.fab.item;

public class GrocessaryItem extends Item {

	public GrocessaryItem(int itemId, String itemName, double price, int quantity) {
		super();
		this.itemId = itemId;
		this.itemName = itemName;
		this.price = price;
		this.quantity = quantity;
		this.amount = quantity * price;
	}

}
