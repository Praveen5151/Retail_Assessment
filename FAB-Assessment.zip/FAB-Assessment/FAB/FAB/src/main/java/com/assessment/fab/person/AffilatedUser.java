package com.assessment.fab.person;

public class AffilatedUser extends User {

	public AffilatedUser(String name, String mobileNumber) {
		super();
		this.name = name;
		this.mobileNumber = mobileNumber;
	}

}
