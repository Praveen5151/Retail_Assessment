package com.assessment.rule;

import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.PriorityQueue;

import com.assessment.fab.bill.Bill;
import com.assessment.fab.item.Item;
import com.assessment.fab.item.ItemsDetails;
import com.assessment.fab.item.NotGrocessayryItem;
import com.assessment.fab.person.AffilatedUser;
import com.assessment.fab.person.Customer;
import com.assessment.fab.person.Employee;
import com.assessment.fab.person.User;

public class RuleUtil {

	static private PriorityQueue<Rule> pQueue = new PriorityQueue<Rule>(new RuleComparator());
	static Rule4 rule4 = new Rule4();

	static {
		pQueue.add(new Rule1());
		pQueue.add(new Rule2());
		pQueue.add(new Rule3());
	}

	public static void main(String[] args) {
		System.out.println(pQueue.size());
	}

	public static void applyRule(Bill bill) {

		for (Rule r : pQueue) {
			if (r.applyRule(bill)) {
				System.out.println("Rule no : [ " + r.priority + " ], applied");
				break;
			}
		}

		if (rule4.applyRule(bill)) {
			System.out.println("Rule no : [ " + rule4.priority + " ], applied");
		} else {
			System.out.println("No rule applied");
		}

	}

	static class RuleComparator implements Comparator<Rule> {

		public int compare(Rule o1, Rule o2) {
			if (o1 != null && o2 != null) {
				if (o1.priority == o2.priority)
					return 0;
				else if (o1.priority > o2.priority) {
					return 1;
				} else {
					return -1;
				}
			} else {
				return -1;
			}

		}

	}

	static abstract class Rule {
		protected int priority;

		public boolean applyRule(Bill bill) {
			return customRule(bill);
		}

		public abstract boolean customRule(Bill bill);
	}

	static class Rule1 extends Rule {

		{
			priority = 1;
		}

		@Override
		public boolean customRule(Bill bill) {
			if (null != bill) {
				User user = bill.getUser();
				if (null != user) {
					if (user instanceof Employee) {
						ItemsDetails itemsHolder = bill.getItemsHolder();
						if (null != itemsHolder) {
							List<Item> gItems = itemsHolder.getgItems();
							NotGrocessayryItem nogrocessaryItem = null;
							if (null != gItems && !gItems.isEmpty()) {
								for (Item gItem : gItems) {
									nogrocessaryItem = (NotGrocessayryItem) gItem;
									double discountAmount = nogrocessaryItem.getAmount() * 0.7;
									nogrocessaryItem.setDiscountAmount(discountAmount);
									itemsHolder.setDiscountAmount(itemsHolder.getDiscountAmount() + discountAmount);

								}
								System.out.println("Applied Rule 2 : For Employee 30 % discount , Amount : ["
										+ nogrocessaryItem.getAmount() + "],discount : ["
										+ itemsHolder.getDiscountAmount() + "]");
								return true;

							} else {
								System.err.println("Null/Empty value found for nogrocessaryItem");
							}
						} else {
							System.err.println("Null/Empty value found for itemsHolder");
						}
					} else {
						System.err.println("Null/Empty value found for Employee");
					}
				} else {
					System.err.println("Null/Empty value found for user");
				}
			}
			return false;
		}

	}

	static class Rule2 extends Rule {

		{
			priority = 2;
		}

		@Override
		public boolean customRule(Bill bill) {
			if (null != bill) {
				User user = bill.getUser();
				if (null != user) {
					if (user instanceof AffilatedUser) {
						ItemsDetails itemsHolder = bill.getItemsHolder();
						if (null != itemsHolder) {
							List<Item> gItems = itemsHolder.getgItems();
							if (null != gItems && !gItems.isEmpty()) {
								NotGrocessayryItem notgrocessaryItem = null;
								for (Item gItem : gItems) {
									notgrocessaryItem = (NotGrocessayryItem) gItem;
									double discountAmount = notgrocessaryItem.getAmount() * 0.9;
									notgrocessaryItem.setDiscountAmount(discountAmount);
									itemsHolder.setDiscountAmount(itemsHolder.getDiscountAmount() + discountAmount);

								}
								System.out.println("Applied Rule 2 : For Affilated 10 % discount , Amount : ["
										+ notgrocessaryItem.getAmount() + "],discount : ["
										+ itemsHolder.getDiscountAmount() + "]");
								return true;
							} else {
								System.err.println("Null/Empty value found for notgrocessaryItem");
							}
						} else {
							System.err.println("Null/Empty value found for itemsHolder");
						}
					} else {
						System.err.println("Null/Empty value found for Employee");
					}
				} else {
					System.err.println("Null/Empty value found for user");
				}
			}
			return false;
		}

	}

	static class Rule3 extends Rule {

		{
			priority = 3;
		}

		@Override
		public boolean customRule(Bill bill) {
			if (null != bill) {
				User user = bill.getUser();
				if (null != user) {
					if (user instanceof Customer) {
						Customer customer = (Customer) user;
						Calendar calendar = Calendar.getInstance();
						calendar.add(Calendar.YEAR, -2);
						Date d1 = calendar.getTime();
						Date registrationDate = ((Customer) user).getRegistrationDate();
						if (registrationDate.before(d1)) {
							ItemsDetails itemsHolder = bill.getItemsHolder();
							if (null != itemsHolder) {
								List<Item> gItems = itemsHolder.getgItems();
								if (null != gItems && !gItems.isEmpty()) {
									NotGrocessayryItem notgrocessaryItem = null;
									for (Item gItem : gItems) {
										notgrocessaryItem = (NotGrocessayryItem) gItem;
										double discountAmount = notgrocessaryItem.getAmount() * 0.1;
										notgrocessaryItem.setDiscountAmount(discountAmount);
										itemsHolder.setDiscountAmount(itemsHolder.getDiscountAmount() + discountAmount);
									}
									System.out.println("Applied Rule 2 : For Affilated 10 % discount , Amount : ["
											+ notgrocessaryItem.getAmount() + "],discount : ["
											+ itemsHolder.getDiscountAmount() + "]");
									return true;

								} else {
									System.err.println("Null/Empty value found for notgrocessaryItem");
								}
							} else {
								System.err.println("Null/Empty value found for itemsHolder");
							}
						} else {
							System.out.println("User is not older than two years");
						}

					}
				} else {
					System.err.println("Null/Empty value found for user");
				}
			}
			return false;
		}

	}

	static class Rule4 extends Rule {

		@Override
		public boolean customRule(Bill bill) {
			if (null != bill) {

				ItemsDetails itemsHolder = bill.getItemsHolder();
				if (itemsHolder != null) {
					double totalAmount = itemsHolder.getTotalAmount();
					if (totalAmount > 100) {
						double tempDis = totalAmount * 0.95;
						if (tempDis < itemsHolder.getDiscountAmount()) {
							itemsHolder.setDiscountAmount(tempDis);
							return true;
						}

					} else {
						System.err.println("totalAmount is less than 100...");
					}
				} else {
					System.err.println("Null/empty value found for itemHolder.");
				}

			}
			return false;

		}

	}
}
