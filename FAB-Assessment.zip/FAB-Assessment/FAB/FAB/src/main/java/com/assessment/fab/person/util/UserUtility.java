package com.assessment.fab.person.util;

public class UserUtility {
	
	// Add utility methods ...

}
