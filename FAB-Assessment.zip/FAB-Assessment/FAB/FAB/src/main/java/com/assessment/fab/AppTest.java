package com.assessment.fab;

import com.assessment.fab.bill.Bill;
import com.assessment.fab.item.GrocessaryItem;
import com.assessment.fab.item.ItemsDetails;
import com.assessment.fab.item.NotGrocessayryItem;
import com.assessment.fab.person.AffilatedUser;


public class AppTest {
	public static void main(String[] args) {
		System.out.println("FAB Test");

		// Create a Bill Object
		Bill bill = new Bill();
		AffilatedUser affilatedUser = new AffilatedUser("AF", "123");

		bill.setUser(affilatedUser);
		ItemsDetails itemsDetails = new ItemsDetails();
		itemsDetails.addItems(new GrocessaryItem(0, "0000", 10, 1));
		bill.setItemsHolder(itemsDetails);

		//bill.applyDiscout();
		//bill.displayBill();

		// Add a Not grocessery Item
		itemsDetails.addItems(new NotGrocessayryItem(1, "1111", 100, 2));
		
		bill.applyDiscout();
		bill.displayBill();

	}
}
