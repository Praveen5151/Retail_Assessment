package com.assessment.fab.item;

import java.util.ArrayList;
import java.util.List;

public class ItemsDetails {

	private List<Item> allItems = new ArrayList<Item>();
	private List<Item> ngItems = new ArrayList<Item>();

	public List<Item> getAllItems() {
		// TO_DO : clone it and return
		return allItems;
	}

	private double totalAmount;
	private double discountAmount;
	private double preDiscountCalculated = 0;

	public void addItems(Item item) {
		totalAmount += item.amount;
		allItems.add(item);
		if (item instanceof NotGrocessayryItem) {
			ngItems.add(item);
			// update discountAmount after apply rule
		} else {
			discountAmount += item.amount;
		}
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public List<Item> getgItems() {
		return ngItems;
	}

	public double getDiscountAmount() {
		return discountAmount;
	}

	public void setDiscountAmount(double discountAmount) {
		this.discountAmount = discountAmount;
	}

	public double getPreDiscountCalculated() {
		return preDiscountCalculated;
	}

	public void setPreDiscountCalculated(double preDiscountCalculated) {
		this.preDiscountCalculated = preDiscountCalculated;
	}

	@Override
	public String toString() {
		return "totalAmount : [ " + totalAmount + " ], discoount Amount : [ " + discountAmount + " ]";
	}

}
