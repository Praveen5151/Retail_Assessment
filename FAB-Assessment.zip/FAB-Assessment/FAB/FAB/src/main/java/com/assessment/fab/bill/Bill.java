package com.assessment.fab.bill;

import com.assessment.fab.item.ItemsDetails;
import com.assessment.fab.person.User;
import com.assessment.rule.RuleUtil;

public class Bill {

	private User user;
	private ItemsDetails itemDetails;

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public ItemsDetails getItemsHolder() {
		return itemDetails;
	}

	public void setItemsHolder(ItemsDetails itemsHolder) {
		this.itemDetails = itemsHolder;
	}

	public void applyDiscout() {
		RuleUtil.applyRule(this);
	}

	public void displayBill() {
		System.out.println("-----------------------------");
		System.out.println(user);

		System.out.println("-----------------------------");
		System.out.println(itemDetails);
		System.out.println("-----------------------------");

	}

}
