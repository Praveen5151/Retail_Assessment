package com.assessment.fab.person;

public class Employee extends User {

	public Employee(String name, String mobileNumber) {
		super();
		this.name = name;
		this.mobileNumber = mobileNumber;
	}
	
	// String empID = ""; Optional
	/*
	 * TO_DO Add employee details
	 * 
	 */

}
