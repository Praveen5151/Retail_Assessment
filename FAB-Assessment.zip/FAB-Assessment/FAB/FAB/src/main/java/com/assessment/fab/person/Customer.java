package com.assessment.fab.person;

import java.util.Date;

public class Customer extends User {
	
	
	public Customer(String name, String mobileNumber, Date registrationDate) {
		super();
		this.name = name;
		this.mobileNumber = mobileNumber;
		this.registrationDate = registrationDate;
	}

	//private String customerID; mobile number can be used for this.
	private Date registrationDate;

	public Date getRegistrationDate() {
		return registrationDate;
	}

	public void setRegistrationDate(Date registrationDate) {
		this.registrationDate = registrationDate;
	}
	
	

}
