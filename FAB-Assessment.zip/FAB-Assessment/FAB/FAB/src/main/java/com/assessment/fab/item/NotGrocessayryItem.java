package com.assessment.fab.item;

public class NotGrocessayryItem extends Item {

	public NotGrocessayryItem(int itemId, String itemName, double price, int quantity) {
		super();
		this.itemId = itemId;
		this.itemName = itemName;
		this.price = price;
		this.quantity = quantity;
		this.amount = quantity * price;
	}

	private double discountAmount;

	public double getDiscountAmount() {
		return discountAmount;
	}

	public void setDiscountAmount(double discountAmount) {
		this.discountAmount = discountAmount;
	}

}
