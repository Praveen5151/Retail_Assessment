# Project Title : FAB-Billing:-

# Assessment:
On a retail website, the following discounts apply:
1. If the user is an employee of the store, he gets a 30% discount
2. If the user is an affiliate of the store, he gets a 10% discount
3. If the user has been a customer for over 2 years, he gets a 5% discount.
4. For every $100 on the bill, there would be a $ 5 discount (e.g. for $ 990, you get $ 45 as a discount).
5. The percentage based discounts do not apply on groceries. 6. A user can get only one of the percentage based discounts on a bill.
 
Write a program with test cases such that given a bill, it finds the net payable amount. Please note the stress is on object oriented approach and test coverage.

 
#You will be evaluated based on following parameters:
 
1. Design principles like SOLID, DRY
2. Maintainability ( or Flexibility / Test-ability)
3. Performance and reliability
4. Scalability

#Getting Started:
1.Operating System Family: windows7

#Installing:
1.JAVA version(JDK  1.5,JRE  1.5)
2.Eclipse luna 64 bit

#Contributing Role:

These instructions will the project up and running on your local machine for development and testing purposes.

First create a pojo classes  name as AffilatedUser,Customer,Employee and User on person pkg and place the src folder.
and second item,itemDetails and GrocessaryItem,NotGrocessaryItem classes for getting desire results.
and Third create RuleUtility is a class, which contains just static class Rule and methods, it is stateless and cannot be instantiated. It contains a bunch of related methods(CustomRule), so they can be reused across the application.
I have declare an object in Bill class and Just pass the id and user id in the constructor and get the desire resukt.
Depends on user is an employee of the store, he gets a discount as per requirement.

case1:  id = 1 and user_id = 1 where it found the user as employee and allocate the 30% discount on non grocies product.
case 2: id = 2 and user_id = 2 where it found the user as affiliated suer and allocate the 10% discount on non grocies product.
case 3: id = 3 and user_id = 3 
 
Here 2 cases occur. if an entry exists into order table of 3 years ago then it will allocate 5% discount else it will allocate 0. You can change the order date and can see the difference.
 
 
# Acknowledgments:

1.Hat tip to anyone whose code was used
2.Inspiration
3.etc
